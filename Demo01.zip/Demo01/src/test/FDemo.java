package test;

public class FDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		 * int i =10; System.out.println("The value of i is := "+i);
		 * 
		 * char c= 'a';
		 * 
		 * System.out.println("         "+c );
		 * 
		 * String s= "Hi";
		 * 
		 * System.out.println(s);
		 * 
		 */
		
		//int a=10, b=20;
		int a=25;
		int b=200;
		int c=30; 
		
		if(a>b && a>c) // True 
		{
			System.out.println("A is Gr" +a);
		}
		
		
		else if(b>c)
		{
			System.out.println("B is Gr "+b);
		}
		
		else
		{
			System.out.println("C is Gr" +c);
		}
		
		

	}

}
